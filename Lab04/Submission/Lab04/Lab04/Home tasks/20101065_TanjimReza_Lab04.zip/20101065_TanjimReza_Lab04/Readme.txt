Even though the test shows 100% while switching STATIC to DCHP but it somehow breaks upon saving.
